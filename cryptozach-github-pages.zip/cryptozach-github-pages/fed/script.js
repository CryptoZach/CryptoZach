// Minimal JS: current year + mailto-form generator

(function () {
  // Footer year
  var yearEl = document.getElementById("year");
  if (yearEl) yearEl.textContent = String(new Date().getFullYear());

  // Contact form -> mailto
  var form = document.getElementById("contactForm");
  var hint = document.getElementById("formHint");

  if (!form) return;

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    var data = new FormData(form);
    var name = (data.get("name") || "").toString().trim();
    var email = (data.get("email") || "").toString().trim();
    var message = (data.get("message") || "").toString().trim();

    if (!name || !email || !message) {
      if (hint) hint.textContent = "Please complete all fields.";
      return;
    }

    var subject = encodeURIComponent("Inquiry (via CryptoZach site): " + name);
    var body = encodeURIComponent(
      "Name: " + name + "\n" +
      "Email: " + email + "\n\n" +
      message + "\n\n" +
      "--\nSent from cryptozach.github.io"
    );

    var mailto = "mailto:zukezach@gmail.com?subject=" + subject + "&body=" + body;

    window.location.href = mailto;

    if (hint) hint.textContent = "Opening your email client…";
  });
})();
